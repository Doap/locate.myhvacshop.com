jQuery(function(){
	jQuery("#et_anticipate_date").datetimepicker();

	jQuery(".ui-datepicker").css( 'clip', 'auto' );

	jQuery( '.settings_page_et_anticipate_options > #ui-datepicker-div' ).css( 'height', 'auto' );
});