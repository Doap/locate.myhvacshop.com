(function($){
	$(document).ready(function() {
		$( '#monarch-override-locations' ).click(function(){
			$( '#monarch_settings_box' ).toggle();
		});
	});
})(jQuery)
